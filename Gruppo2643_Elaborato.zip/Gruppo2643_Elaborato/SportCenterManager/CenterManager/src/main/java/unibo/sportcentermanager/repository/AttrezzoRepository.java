package unibo.sportcentermanager.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import unibo.sportcentermanager.entity.Attrezzo;

public interface AttrezzoRepository extends JpaRepository<Attrezzo, Integer> {}